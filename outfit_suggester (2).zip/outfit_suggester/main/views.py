
from django.shortcuts import render

def home(request):
    """Render the homepage."""
    return render(request, 'main/index.html')


from django.shortcuts import render
from django.http import JsonResponse
import os
import requests
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables
load_dotenv()

# Initialize clients with environment variables
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
WEATHER_API_KEY = os.getenv('WEATHER_API_KEY')

def home(request):
    """Render the homepage."""
    return render(request, 'main/index.html')


def style_info(request):
    """Provide fashion style information as a JSON response."""
    try:
        categories_response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful fashion assistant."},
                {"role": "user", "content": "List and categorize different types of fashion styles."}
            ],
            max_tokens=150
        )

        categories = categories_response.choices[0].message.content
        return JsonResponse({"status": "success", "data": categories})

    except Exception as e:
        return JsonResponse({"status": "error", "message": f"An error occurred: {e}"})


def suggest_outfit(request):
    """Generate outfit suggestion based on event, location, and weather data."""
    event = request.GET.get("event")
    location = request.GET.get("location")

    if not event or not location:
        return JsonResponse({"status": "error", "message": "Event and location are required."})

    weather_data = get_weather(location)
    if not weather_data:
        return JsonResponse({"status": "error", "message": f"Couldn't fetch weather data for {location}."})

    try:
        suggestion = get_outfit_suggestion(event, location, weather_data)
        return JsonResponse({"status": "success", "data": suggestion})

    except Exception as e:
        return JsonResponse({"status": "error", "message": f"Error generating outfit suggestion: {e}"})


def get_weather(city):
    """Fetch weather data for a given city."""
    try:
        params = {
            'q': city,
            'appid': WEATHER_API_KEY,
            'units': 'metric'
        }
        response = requests.get("https://api.openweathermap.org/data/2.5/weather", params=params)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        return None


def get_outfit_suggestion(event, location, weather_data):
    """Generate outfit suggestion using OpenAI."""
    temperature = weather_data['main']['temp']
    weather_desc = weather_data['weather'][0]['description']
    humidity = weather_data['main']['humidity']

    messages = [
        {"role": "system", "content": "You are a detailed fashion advisor."},
        {"role": "user", "content": f"""
            Suggest an outfit for a {event} in {location}.
            Weather:
            - Temperature: {temperature}°C
            - Conditions: {weather_desc}
            - Humidity: {humidity}%
            and for men  for women or chiled 
        """}
    ]

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        max_tokens=400
    )

    return response.choices[0].message.content

