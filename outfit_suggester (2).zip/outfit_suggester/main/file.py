# import os
# from openai import OpenAI

# # Initialize the client
# client = OpenAI(
#     api_key='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'  # Replace with your actual API key
# )

# def get_gpt4_response(prompt, temperature=0.7, max_tokens=150):
#     """
#     Send a prompt to GPT-4 and get the response.
    
#     Args:
#         prompt (str): The input text to send to GPT-4
#         temperature (float): Controls randomness (0-1)
#         max_tokens (int): Maximum length of the response
        
#     Returns:
#         str: The model's response
#     """
#     try:
#         response = client.chat.completions.create(
#             model="gpt-4o",
#             messages=[
#                 {"role": "user", "content": prompt}
#             ],
#             temperature=temperature,
#             max_tokens=max_tokens
#         )
#         return response.choices[0].message.content
#     except Exception as e:
#         return f"An error occurred: {str(e)}"

# # Example usage
# if __name__ == "__main__":
#     # Set your API key as an environment variable
#     os.environ['OPENAI_API_KEY'] = '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'
    
#     # Example prompt
#     prompt = "Explain quantum computing in one sentence."
    
#     # Get and print the response
#     response = get_gpt4_response(prompt)
#     print(f"Prompt: {prompt}")
#     print(f"Response: {response}")



from openai import OpenAI

# Initialize the OpenAI client
client = OpenAI(
    api_key='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'
)

def style_info():
    # First API call to get fashion categories
    initial_messages = [
        {"role": "system", "content": "You are a helpful and friendly fashion assistant."},
        {"role": "user", "content": "List and categorize different types of fashion styles."}
    ]

    try:
        # Get fashion categories
        categories_response = client.chat.completions.create(
            model="gpt-4o",
            messages=initial_messages,
            max_tokens=150
        )
        
        print("\nFashion Categories:")
        print(categories_response.choices[0].message.content)
        
        # Get user's preferred style
        fashion_style = input("\nWhat type of style do you like most of the time? ")
        
        # Second API call to analyze user's style
        style_messages = [
            {"role": "system", "content": "You are a helpful and friendly fashion assistant."},
            {"role": "user", "content": f"""
            The user likes {fashion_style} style.
            Please provide:
            1. An appreciation of this style choice
            2. Explain why this style is attractive
            3. Suggest some key pieces for this style
            """}
        ]
        
        # Get style analysis
        style_response = client.chat.completions.create(
            model="gpt-4o",
            messages=style_messages,
            max_tokens=200
        )
        
        print("\nStyle Analysis:")
        print(style_response.choices[0].message.content)

    except Exception as e:
        print("An error occurred:", str(e))
        print("If you're getting a model not found error, please verify the correct model identifier for GPT-4O in your OpenAI dashboard.")

# Example usage
if __name__ == "__main__":
    style_info()