
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('style_info/', views.style_info, name='style_info'),
    path('suggest_outfit/', views.suggest_outfit, name='suggest_outfit'),
]
