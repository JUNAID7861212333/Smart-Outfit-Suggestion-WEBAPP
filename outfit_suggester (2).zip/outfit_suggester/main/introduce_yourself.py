# from openai import OpenAI
# import requests
# from openai import OpenAI
# from datetime import datetime


# Initialize the OpenAI client
# client = OpenAI(
#     api_key='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'  # Replace with your actual API key
# )

# def get_user_introduction():
#     # Gather user input
#     name = input("Please enter your name: ")
#     age = input("Please enter your age: ")
#     education = input("Please enter your education: ")
#     marital_status = input("Please enter your marital status: ")
#     living_style = input("Please enter your living style: ")
#     address = input("Please enter your address: ")


#     # Construct the messages for GPT-4O
#     messages = [
#         {"role": "system", "content": "You are a helpful and friendly assistant."},
#         {"role": "user", "content": f"""
#             Hi! Please introduce yourself to the user  like hi name of user i am chat gptexplain it what chat gtp is and how it helpfull for user :

#             Name: {name}

#             The response should sound friendly and welcoming.
#         """}
#     ]

#     try:
#         # Generate a response using GPT-4O
#         response = client.chat.completions.create(
#             model="gpt-4o",  # Using GPT-4O model
#             messages=messages,
#             max_tokens=150
#         )

#         # Print the response
#         print("\nGPT-4O's Response:")
#         print(response.choices[0].message.content)

#     except Exception as e:
#         print("An error occurred:", str(e))
#         print("If you're getting a model not found error, please verify the correct model identifier for GPT-4O in your OpenAI dashboard.")


# def style_info():
#     # First API call to get fashion categories
#     initial_messages = [
#         {"role": "system", "content": "You are a helpful and friendly fashion assistant."},
#         {"role": "user", "content": "List and categorize different types of fashion styles."}
#     ]

#     try:
#         # Get fashion categories
#         categories_response = client.chat.completions.create(
#             model="gpt-4o",
#             messages=initial_messages,
#             max_tokens=150
#         )

#         print("\nFashion Categories:")
#         print(categories_response.choices[0].message.content)

#         # Get user's preferred style
#         fashion_style = input("\nWhat type of style do you like most of the time? ")

#         # Second API call to analyze user's style
#         style_messages = [
#             {"role": "system", "content": "You are a helpful and friendly fashion assistant."},
#             {"role": "user", "content": f"""
#             The user likes {fashion_style} style.
#             Please provide:
#             1. An appreciation of this style choice
#             2. Explain why this style is attractive
#             3. Suggest some key pieces for this style
#             """}
#         ]

#         # Get style analysis
#         style_response = client.chat.completions.create(
#             model="gpt-4o",
#             messages=style_messages,
#             max_tokens=200
#         )

#         print("\nStyle Analysis:")
#         print(style_response.choices[0].message.content)

#     except Exception as e:
#         print("An error occurred:", str(e))
#         print("If you're getting a model not found error, please verify the correct model identifier for GPT-4O in your OpenAI dashboard.")


# # Weather API configuration
# WEATHER_API_KEY = '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'  # Replace with your OpenWeatherMap API key
# WEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${KEY}"

# def get_weather(city):
#     """Fetch weather data for a given city"""
#     try:
#         params = {
#             'q': city,
#             'appid': WEATHER_API_KEY,
#             'units': 'metric'  # For temperature in Celsius
#         }
#         response = requests.get(WEATHER_BASE_URL, params=params)
#         response.raise_for_status()
#         return response.json()
#     except requests.RequestException as e:
#         print(f"Error fetching weather data: {e}")
#         return None

# def parse_outfit_request(user_input):
#     """Parse user input to extract event and location information"""
#     event = None
#     location = None

#     # Convert input to lowercase for easier parsing
#     input_lower = user_input.lower()
#     words = input_lower.split()

#     # Look for location after "in" keyword
#     if 'in' in words:
#         in_index = words.index('in')
#         if in_index + 1 < len(words):
#             location = words[in_index + 1].capitalize()

#     # Look for event types
#     event_keywords = {
#         'party': 'party',
#         'wedding': 'wedding',
#         'dinner': 'dinner',
#         'meeting': 'meeting',
#         'date': 'date',
#         'interview': 'interview',
#         'function': 'function',
#         'ceremony': 'ceremony',
#         'festival': 'festival',
#         'celebration': 'celebration'
#     }

#     # Find event type in input
#     for word in words:
#         if word in event_keywords:
#             event = event_keywords[word]
#             break

#     # If no location found, ask for it
#     if not location:
#         location = input("Please specify the city/location: ").capitalize()

#     # If no event found, ask for it
#     if not event:
#         event = input("What type of event are you attending? (e.g., party, wedding, dinner): ").lower()
#         # Validate event input
#         while event not in event_keywords:
#             print("Please specify a valid event type (party, wedding, dinner, meeting, etc.)")
#             event = input("What type of event are you attending?: ").lower()

#     return event, location

# def get_outfit_suggestion(event, location, weather_data):
#     """Get outfit suggestion from GPT-4O based on event and weather"""
#     try:
#         temperature = weather_data['main']['temp']
#         weather_desc = weather_data['weather'][0]['description']
#         humidity = weather_data['main']['humidity']

#         messages = [
#             {"role": "system", "content": "You are a helpful fashion advisor who provides detailed outfit suggestions based on events and weather conditions."},
#             {"role": "user", "content": f"""
#             Please suggest an appropriate outfit for a {event} in {location}.
#             Current weather conditions:
#             - Temperature: {temperature}°C
#             - Weather: {weather_desc}
#             - Humidity: {humidity}%

#             Please provide:
#             1. Complete outfit suggestion (top to bottom, including accessories)
#             2. Explanation why this outfit is suitable for the weather and event
#             3. Any specific tips considering the location and weather conditions

#             Make the response friendly and detailed.
#             """}
#         ]

#         response = client.chat.completions.create(
#             model="gpt-4o",
#             messages=messages,
#             max_tokens=300
#         )

#         return response.choices[0].message.content

#     except Exception as e:
#         return f"Error generating outfit suggestion: {str(e)}"

# def suggest_outfit():
#     """Main function to handle outfit suggestions"""
#     print("Welcome to the Smart Outfit Suggester!")
#     print("You can ask questions like 'What should I wear for a party in Lahore?' or 'suggest outfit for wedding in Karachi'")

#     while True:
#         user_input = input("\nWhat would you like to wear? (or 'quit' to exit): ")

#         if user_input.lower() == 'quit':
#             break

#         # Parse the request
#         event, location = parse_outfit_request(user_input)

#         # Get weather data
#         weather_data = get_weather(location)
#         if not weather_data:
#             print(f"Couldn't fetch weather data for {location}. Please check the location name.")
#             continue

#         # Get and display outfit suggestion
#         print("\nGenerating outfit suggestion based on weather and event...")
#         suggestion = get_outfit_suggestion(event, location, weather_data)
#         print("\nOutfit Suggestion:")
#         print(suggestion)

#         # Ask if user wants another suggestion
#         continue_response = input("\nWould you like another outfit suggestion? (yes/no): ")
#         if continue_response.lower() != 'yes':
#             break

# if __name__ == "__main__":
#     get_user_introduction()
#     style_info()
#     suggest_outfit()


import os
from dotenv import load_dotenv
import requests
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables
load_dotenv()

os.getenv('OPENAI_API_KEY')

# Initialize clients with environment variables
client = OpenAI()
WEATHER_API_KEY = os.getenv('WEATHER_API_KEY')


def get_user_introduction():
    """Gather user information and generate an introduction"""
    name = input("Please enter your name: ")

    messages = [
        {"role": "system", "content": "You are a helpful and friendly assistant."},
        {"role": "user", "content": f"""
            Hi! Please introduce yourself to {name}.
            Explain what an AI assistant is and how it can be helpful.
            Be friendly and welcoming.
        """}
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            max_tokens=150
        )

        print("\nAI Assistant's Introduction:")
        print(response.choices[0].message.content)

    except Exception as e:
        print(f"An error occurred: {e}")
        print("Please verify your OpenAI API configuration.")


def style_info():
    """Provide fashion style information"""
    try:
        # Get fashion categories
        categories_response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful fashion assistant."},
                {"role": "user", "content": "List and categorize different types of fashion styles."}
            ],
            max_tokens=150
        )

        print("\nFashion Categories:")
        print(categories_response.choices[0].message.content)

        # Get user's preferred style
        fashion_style = input("\nWhat type of style do you like most? ")

        # Analyze user's style
        style_response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful fashion assistant."},
                {"role": "user", "content": f"""
                The user likes {fashion_style} style.
                Please provide:
                1. An appreciation of this style choice
                2. Explain why this style is attractive
                3. Suggest some key pieces for this style
                """}
            ],
            max_tokens=200
        )

        print("\nStyle Analysis:")
        print(style_response.choices[0].message.content)

    except Exception as e:
        print(f"An error occurred: {e}")
        print("Please verify your OpenAI API configuration.")


def get_weather(city):
    """Fetch weather data for a given city"""
    try:
        params = {
            'q': city,
            'appid': WEATHER_API_KEY,
            'units': 'metric'
        }
        response = requests.get(f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric")
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        print(f"Error fetching weather data: {e}")
        return None


def parse_outfit_request(user_input):
    """Parse user input to extract event and location information"""
    input_lower = user_input.lower()
    words = input_lower.split()

    # Predefined event types and locations
    event_keywords = {
        'party', 'wedding', 'dinner', 'meeting',
        'date', 'interview', 'function',
        'ceremony', 'festival', 'celebration'
    }

    event = next((word for word in words if word in event_keywords), None)

    # Find location after 'in'
    location = None
    if 'in' in words:
        in_index = words.index('in')
        if in_index + 1 < len(words):
            location = words[in_index + 1].capitalize()

    # Prompt for missing information
    if not location:
        location = input("Please specify the city/location: ").capitalize()

    if not event:
        print("Available event types:", ", ".join(event_keywords))
        event = input("What type of event are you attending? ").lower()
        while event not in event_keywords:
            print("Invalid event type. Please choose from the list.")
            event = input("What type of event are you attending? ").lower()

    return event, location


def get_outfit_suggestion(event, location, weather_data):
    """Generate outfit suggestion using OpenAI"""
    try:
        temperature = weather_data['main']['temp']
        weather_desc = weather_data['weather'][0]['description']
        humidity = weather_data['main']['humidity']

        messages = [
            {"role": "system", "content": "You are a detailed fashion advisor."},
            {"role": "user", "content": f"""
            Suggest an outfit for a {event} in {location}.
            Weather:
            - Temperature: {temperature}°C
            - Conditions: {weather_desc}
            - Humidity: {humidity}%

            Provide:
            1. Complete outfit (top to bottom, with accessories)
            2. Why this outfit suits the event and weather
            3. Location-specific styling tips
            """}
        ]

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            max_tokens=300
        )

        return response.choices[0].message.content

    except Exception as e:
        return f"Error generating outfit suggestion: {e}"


def suggest_outfit():
    """Main outfit suggestion interface"""
    print("Welcome to the Smart Outfit Suggester!")
    print("Ask: 'What should I wear for a party in Lahore?'")

    while True:
        user_input = input(
            "\nWhat would you like to wear? (or 'quit' to exit): ")

        if user_input.lower() == 'quit':
            break

        event, location = parse_outfit_request(user_input)

        # Get weather data
        weather_data = get_weather(location)
        if not weather_data:
            print(f"Couldn't fetch weather data for {location}.")
            continue

        print("\nGenerating outfit suggestion...")
        suggestion = get_outfit_suggestion(event, location, weather_data)
        print("\nOutfit Suggestion:")
        print(suggestion)

        continue_response = input("\nAnother suggestion? (yes/no): ")
        if continue_response.lower() != 'yes':
            break


# if __name__ == "__main__":
#     # get_user_introduction()
#     style_info()
#     suggest_outfit()



import tkinter as tk
from tkinter import scrolledtext

# Sample functions to simulate your style_info and suggest_outfit
def style_info():
    return "This style is casual and comfortable."

def suggest_outfit():
    return "Try a pair of jeans with a white T-shirt and sneakers."

# Function to handle the question and display the answer
def get_answer():
    question = question_entry.get()
    if question:
        answer = f"Style Info: {style_info()}\nSuggested Outfit: {suggest_outfit()}"
        output_text.insert(tk.END, f"You: {question}\n{answer}\n\n")
        question_entry.delete(0, tk.END)
    else:
        output_text.insert(tk.END, "Please enter a question.\n\n")

# Set up the main application window
root = tk.Tk()
root.title("Style Assistant")

# Input field for questions
question_label = tk.Label(root, text="Ask a style question:")
question_label.pack(pady=5)
question_entry = tk.Entry(root, width=50)
question_entry.pack(pady=5)

# Button to submit the question
submit_button = tk.Button(root, text="Get Answer", command=get_answer)
submit_button.pack(pady=5)

# Scrollable text area to display conversation
output_text = scrolledtext.ScrolledText(root, width=60, height=15, wrap=tk.WORD)
output_text.pack(pady=10)

# Run the main event loop
root.mainloop()
